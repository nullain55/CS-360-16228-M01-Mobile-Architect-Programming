package com.zybooks.thomasmartin_3_2_assignment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private EditText nameText;
    private Button buttonSayHello, requestSmsPermissionButton, sendSmsButton;
    private TextView textGreeting, smsPermissionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);
        requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);
        sendSmsButton = findViewById(R.id.sendSmsButton);
        smsPermissionText = findViewById(R.id.smsPermissionText);

        // Initially disable the "Say Hello" button
        buttonSayHello.setEnabled(false);

        // Add TextWatcher to dynamically enable/disable "Say Hello" button
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button if there is text, disable otherwise
                buttonSayHello.setEnabled(s.length() > 0);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not used
            }
        });

        // Check if SMS permission is already granted
        if (checkSmsPermission()) {
            updateUIForPermissionGranted();
        }

        // Request SMS permission
        requestSmsPermissionButton.setOnClickListener(v -> {
            if (!checkSmsPermission()) {
                requestSmsPermission();
            }
        });

        // Send SMS notification if permission is granted
        sendSmsButton.setOnClickListener(v -> {
            sendSmsNotification();
        });
    }

    // SayHello function triggered when the "Say Hello" button is clicked
    public void SayHello(View view) {
        String name = nameText.getText().toString();

        // If nameText is empty, return from the function
        if (name.isEmpty()) {
            return;
        }

        // Otherwise, display the greeting
        textGreeting.setText("Hello, " + name + "!");
    }

    // Check if SMS permission is granted
    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission from the user
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Handle the user's response to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                updateUIForPermissionGranted();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Update the UI if permission is granted
    private void updateUIForPermissionGranted() {
        sendSmsButton.setVisibility(View.VISIBLE);
        requestSmsPermissionButton.setVisibility(View.GONE);
        smsPermissionText.setText("Permission granted! You can now send SMS notifications.");
    }

    // Send SMS notification (example: low inventory)
    private void sendSmsNotification() {
        String phoneNumber = "1234567890";  // Replace with actual number
        String message = "Alert: Low Inventory!";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Notification Sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed to Send", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
