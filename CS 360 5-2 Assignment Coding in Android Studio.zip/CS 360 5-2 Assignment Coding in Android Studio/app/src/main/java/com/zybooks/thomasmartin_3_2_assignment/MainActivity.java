package com.zybooks.thomasmartin_3_2_assignment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Initially disable the button
        buttonSayHello.setEnabled(false);

        // Add TextWatcher to dynamically enable/disable button
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button if there is text, disable otherwise
                buttonSayHello.setEnabled(s.length() > 0);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    // SayHello function triggered when the button is clicked
    public void SayHello(View view) {
        String name = nameText.getText().toString();

        // If nameText is empty, return from the function
        if (name.isEmpty()) {
            return;
        }

        // Otherwise, display the greeting
        textGreeting.setText("Hello, " + name + "!");
    }
}
